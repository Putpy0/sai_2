import pandas as pd
import tensorflow as tf
import yaml
import numpy as np
from model.tokenizer import SimpleTokenizer
from model.model import SimpleTokenizer

# Load config
with open("config.yaml") as f:
    config = yaml.safe_load(f)

# 1. Load Data
df = pd.read_csv(config['paths']['data'])
texts = df['text'].tolist()
labels = np.array(df['label'].map({'finance':0, 'crypto':1}).tolist())

# 2. Train Tokenizer
tokenizer = SimpleTokenizer()
tokenizer.train(config['paths']['data'])
tokenizer.save(config['paths']['tokenizer'])

# 3. Encode Data
encoded = [tokenizer.encode(text) for text in texts]
max_len = max(len(x) for x in encoded)
padded = tf.keras.preprocessing.sequence.pad_sequences(
    encoded, maxlen=max_len, padding='post'
)

# 4. Build Model
model = SimpleModel(config['model'])
model.compile(
    optimizer=tf.keras.optimizers.Adam(config['training']['learning_rate']),
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# 5. Train
model.fit(
    padded,
    labels,
    epochs=config['training']['epochs'],
    batch_size=config['training']['batch_size']
)

# 6. Save Model
model.save("model/simple_model.h5")
print("\nTraining selesai! Model disimpan di model/simple_model.h5")