from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders

class SimpleTokenizer:
    def __init__(self):
        self.tokenizer = Tokenizer(models.BPE())
        self.trainer = trainers.BpeTrainer(
            vocab_size=1000,
            special_tokens=["[PAD]", "[UNK]"]
        )
        self.tokenizer.pre_tokenizer = pre_tokenizers.Whitespace()
        self.tokenizer.decoder = decoders.BPEDecoder()

    def train(self, file_path):
        self.tokenizer.train(files=[file_path], trainer=self.trainer)

    def save(self, path):
        self.tokenizer.save(path + "tokenizer.json")

    def load(self, path):
        self.tokenizer = Tokenizer.from_file(path + "tokenizer.json")

    def encode(self, text):
        return self.tokenizer.encode(text).ids