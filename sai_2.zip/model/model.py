import tensorflow as tf

class SimpleModel(tf.keras.Model):
    def __init__(self, config):
        super().__init__()
        self.embedding = tf.keras.layers.Embedding(
            input_dim=config['vocab_size'],
            output_dim=config['embedding_dim']
        )
        self.transformer = tf.keras.layers.Transformer(
            num_layers=config['num_layers'],
            d_model=config['embedding_dim'],
            num_heads=config['num_heads'],
            ff_dim=config['ff_dim']
        )
        self.classifier = tf.keras.layers.Dense(2, activation='softmax')

    def call(self, inputs):
        x = self.embedding(inputs)
        x = self.transformer(x, x)
        return self.classifier(x[:, 0, :])